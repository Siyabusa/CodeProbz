﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;


namespace SalesTax
{
    class AppLogic
    {
        static Double NormalTax = 0.1;//create static value for normal tax
        static Double ImportTax = 0.05;//create static value for import tax
        static Double totalTax = NormalTax + ImportTax;//create static value for full/combined tax
        ArrayList goods;
        public AppLogic()
        {
            goods = new ArrayList();
            
            getItemsInput1(); //input 1            
            addTax();
            Console.WriteLine("INPUT 1");
            Console.WriteLine("======================="); 
            displayWithoutTax();
            Console.WriteLine("=======================");
            Console.WriteLine("OUTPUT 1");
            displayWithTax();

            Console.WriteLine();            
            
            getItemsInput2(); //input 2            
            addTax();
            Console.WriteLine("INPUT 2");
            Console.WriteLine("======================="); 
            displayWithoutTax();
            Console.WriteLine("=======================");
            Console.WriteLine("OUTPUT 2");
            displayWithTax();

            Console.WriteLine();           
            
            getItemsInput3(); //input 3
            addTax();
            Console.WriteLine("INPUT 3");
            Console.WriteLine("======================="); 
            displayWithoutTax();
            Console.WriteLine("=======================");
            Console.WriteLine("OUTPUT 3");
            displayWithTax();

            Console.WriteLine("=====================");
        }


        //Inject inputs for input 1
        public void getItemsInput1()
        {
            Item first = new Item(1, "book", 12.49,"local","book");
            Item two = new Item(1, "CD", 14.99,"local", "CD");
            Item third = new Item(1, "chocolate bar", 0.85,"local","food");
            goods.Add(first);
            goods.Add(two);
            goods.Add(third);
        }

        //Inject inputs for input 2
        public void getItemsInput2()
        {
            if (goods.Count > 0)
            {
                goods.Clear();
            }            
            Item first = new Item(1, "imported box of chocolates", 10.00,"imported","food");
            Item two = new Item(1, "imported box of perfume", 47.50,"imported", "perfume");            
            goods.Add(first);
            goods.Add(two);            
        }

        //Inject inputs for input 3
        public void getItemsInput3()
        {
            if (goods.Count > 0)
            {
                goods.Clear();
            }       
            Item first = new Item(1, "imported bottle of perfume", 27.99,"imported","perfume");
            Item two = new Item(1, "bottle of perfume", 18.99,"local","perfume");
            Item third = new Item(1, "packet of headache pills", 9.75,"local","medical");
            Item fourth = new Item(1, "imported box of chocolates", 11.25,"imported","food");
            goods.Add(first);
            goods.Add(two);
            goods.Add(third);
            goods.Add(fourth);
        }

        public void addTax()
        {
            //totalTax = 0.0;            
            Double tempTax = 0.0; //create temp variable to hold the tax value
            foreach (Item i in goods)
            {
                //check for imported goods to determine tax assignment
                if (i.getOrigin().Contains("imported"))
                {

                    if ((i.getItemType().Contains("book")) || ((i.getItemType().Contains("food"))) || ((i.getItemType().Contains("medical"))))
                    {
                        tempTax = i.getPrice() * ImportTax; //assign import tax for specific item types(food, books,medical)
                    }
                    else
                    {
                        tempTax = i.getPrice() * totalTax; //assign full tax which is normal and import tax
                    }                                     
                    tempTax = Math.Ceiling(tempTax * 20) / 20; //round up to the nearest 0.05                
                    i.settPrice(i.getPrice() + tempTax); //set the current item's real Price, thus including tax             
                }
                else if ((i.getItemType().Equals("book")) || (i.getItemType().Equals("food")) || (i.getItemType().Equals("medical")))
                {                    
                    i.settPrice(i.getPrice()); //no tax for exempt goods
                }
                else
                {                    
                    tempTax = i.getPrice() * NormalTax;
                    tempTax = Math.Ceiling(tempTax * 20) / 20;
                    i.settPrice(i.getPrice() + tempTax);
                }
            }
        }

        public void displayWithoutTax()
        {
            
            foreach (Item i in goods)
            {
                i.toStringWithoutTax(); //for each of the items, call and display the items that utilizes the norminal prices
            }
        }
        public void displayWithTax()
        {
            
            Double grandTax = 0.00;
            Double grandTotal = 0.00;
            foreach (Item i in goods)
            {
                i.toStringWithTax(); //for each of the items, call and display the items that utilizes the norminal prices
                grandTax += i.gettPrice() - i.getPrice(); //sum up the tax on all the items
                grandTotal += i.gettPrice(); // sum up the real prices of the items
            }
            grandTax = Math.Round(grandTax, 2);            
            Console.WriteLine("Sales Taxes: "+ grandTax);
            Console.WriteLine("Total: " + grandTotal);
        }
    }
}
