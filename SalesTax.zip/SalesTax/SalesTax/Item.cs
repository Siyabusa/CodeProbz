﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SalesTax
{
    class Item
    {
        int quantity;
        String itemType;
        String Origin;
        String name;
        Double price,tprice;  // tprice for price including tax
        //Double tax leave for now

        //Constructor with key variables
        public Item(int q, String Name, Double p, String or, String iType)
        {
            quantity = q;
            itemType = iType;
            price = p;
            Origin = or;
            name = Name;
        }

        public void setName(String n)
        {
            name = n;
        }

        public String getName()
        {
            return name;
        }

        public void setQuantity(int q)
        {
            quantity = q;
        }

        public int getQuantity()
        {
            return quantity;
        }

        public void setItemType(String iType)
        {
            itemType = iType;
        }

        public String getItemType()
        {
            return itemType;
        }

        public void setPrice(Double p)
        {
            price = p;
        }

        public Double getPrice()
        {
            return price;
        }

        public void settPrice(Double pp)
        {
            tprice = pp;
        }

        public Double gettPrice()
        {
            return tprice;
        }

        public void setOrigin(String or)
        {
            Origin = or;
        }

        public String getOrigin()
        {
            return Origin;
        }

        public void toStringWithoutTax()
        {
            //display the slip for this item without tax
                       
            Console.WriteLine(quantity + " " + name + " at " + price);
        }

        public void toStringWithTax()
        {
            //display the slip for this item with tax
            
            Console.WriteLine(quantity + " " + name + " at " +tprice);
        }
    }
}
