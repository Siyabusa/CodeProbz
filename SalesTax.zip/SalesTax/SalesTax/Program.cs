﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SalesTax
{
    class Program
    {
        static void Main(string[] args)
        {
            AppLogic app = new AppLogic(); //run application       
            Console.ReadLine();
        }
    }
}
